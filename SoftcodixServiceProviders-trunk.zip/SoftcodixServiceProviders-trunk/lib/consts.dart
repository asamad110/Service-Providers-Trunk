import 'package:flutter/material.dart';

final String CRYPTO_RANK_API_KEY = "";
final double HEADING_SIZE = 18.0;
final double BODY_SIZE = 16.0;
final double PARA_SIZE = 14.0;
final Color? DEFAULT_DIALOG_BUTTON_COLOR = Color(0xff1e1c99);
