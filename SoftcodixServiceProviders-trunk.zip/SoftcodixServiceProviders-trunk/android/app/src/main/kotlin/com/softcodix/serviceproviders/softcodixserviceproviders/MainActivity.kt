package com.softcodix.serviceproviders.softcodixserviceproviders

import io.flutter.embedding.android.FlutterFragmentActivity

class MainActivity: FlutterFragmentActivity()
